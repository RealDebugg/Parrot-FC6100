﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace plftool
{
    class Program
    {
        static void Main(string[] args)
        {
            if (args.Length == 0)
            {
                Console.WriteLine("Usage: plftool -i [Input plf File] -o [Ouput Directory]");
                return;

            }
            var options = new ProgOptions(args);
            if (!options.isValid) {
                Console.WriteLine(options.message);
                return;
            }
            Console.Write("Analyzing " + options.inputFile + "....");
            var plf = new plfFile(options.inputFile);
            Console.Write("done.\r\n");
            Console.WriteLine(plf.sections.Count().ToString()+" Sections found.");
            Console.Write("Extracting sections to "+options.ouputPath +"....");
            plf.saveSections(options.ouputPath);
            Console.Write("done.\r\n");
            Console.WriteLine("Success!\r\n");
        }
    }

    class ProgOptions
    {
        public bool isValid = true;
        public string inputFile;
        public string ouputPath;
        public string message;
        public ProgOptions(string[] args)
        {
            for (int i = 0; i < args.Length; i++)
            {
                var arg = args[i];
                switch (arg)
                {
                    case "-i":
                        i++;
                        inputFile = args[i];
                        break;
                    case "-o":
                        i++;
                        ouputPath = args[i];
                        break;
                    default:
                        message = "Unrecognized argument: "+args[i];
                        isValid = false;
                        break;
                }
            }
        }
    }
}
