﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.IO;
using System.IO.Compression;
namespace plftool
{
    public class plfFile
    {  
        private plfHeader header;
        private string[][] fileTypes=new string[][]{
            new string[]{ /* fileType=0 UNKNOWN */
                "",                 /* 0x00 */
                "",                 /* 0x01 */
                "",                 /* 0x02 */
                "",                 /* 0x03 */
                "",                 /* 0x04 */
                "",                 /* 0x05 */
                "",                 /* 0x06 */
                "",                 /* 0x07 */
                "",                 /* 0x08 */
                "",                 /* 0x09 */
                "",                 /* 0x0a */
                "",                 /* 0x0b */
                "",                 /* 0x0c */
                "",                 /* 0x0d */
                "",                 /* 0x0e */
                ""                  /* 0x0f */
            },
            new string[]{ /* fileType=1 EXECUTABLE */
                "zimage",           /* 0x00 */
                "",                 /* 0x01 */
                "",                 /* 0x02 */
                "initrd",           /* 0x03 */
                "",                 /* 0x04 */
                "",                 /* 0x05 */
                "",                 /* 0x06 */
                "bootparams.txt",   /* 0x07 */
                "",                 /* 0x08 */
                "",                 /* 0x09 */
                "",                 /* 0x0a */
                "",                 /* 0x0b */
                "",                 /* 0x0c */
                "",                 /* 0x0d */
                "",                 /* 0x0e */
                ""                  /* 0x0f */
            },
            new string[]{ /* fileType=2 ARCHIVE */
                "",                 /* 0x00 */
                "",                 /* 0x01 */
                "",                 /* 0x02 */
                "main_boot.plf",    /* 0x03 */
                "",                 /* 0x04 */
                "",                 /* 0x05 */
                "",                 /* 0x06 */
                "bootloader.bin",   /* 0x07 */
                "",                 /* 0x08 */
                "file_action",      /* 0x09 */
                "",                 /* 0x0a */
                "volume_config",    /* 0x0b */
                "installer.plf",    /* 0x0c */
                "",                 /* 0x0d */
                "",                 /* 0x0e */
                ""                  /* 0x0f */
            }
        };
        //private List<byte> plfFileData = new List<byte>();
        public string filePath;
        public bool fileLoaded = false;
        public List<plfSection> sections = new List<plfSection>();
        public plfSection test;
        public plfSection test2;
        public plfSection test3;
        public plfFile()
        {
        }
        public plfFile(string fileName)
        {
            load(fileName);
            parseSections();
            fileLoaded = true;
        }
        public int load(string fileName)
        {
            byte[] buffer;
            buffer = File.ReadAllBytes(fileName);
            header = new plfHeader(buffer.Take(56).ToArray());
            filePath = fileName;
            return 1;
        }
        public int parseSections()
        {
            int i =0;
            int fileSize = Convert.ToInt32(header.FileSize);
            var fs = File.OpenRead(filePath);
            fs.Position = Convert.ToInt32(header.HdrSize);
            while(fs.Position<fileSize)
            {
                byte[] buffer = new byte[20];
                
                fs.Read(buffer, 0, buffer.Length);
                var toAdd = new plfSection(buffer,fs.Position);
                var size = Convert.ToInt32(toAdd.SectionSize);
                var remainder = size % 4;
                fs.Position += Convert.ToInt32(toAdd.SectionSize);
                //the remainder of the last work in the file is filled with blank bytes, these must be ignored.
                if (remainder > 0)
                    fs.Position += 4 - remainder;                     
                sections.Add(toAdd);

                //uncoment this to limit the number of sections parsed.
                //if (i > 22) break;
                i++;
            }
            fs.Close();
            return 1;
        }
        public int saveSection(string path,int sectionNumber)
        {
            if (!Directory.Exists(path)) Directory.CreateDirectory(path);
            if (!Directory.Exists(path + "\\UNHANDLED\\")) Directory.CreateDirectory(path + "\\UNHANDLED\\");
            if (!fileLoaded) return 0;
            var toSave = sections[sectionNumber];
            int headerFT = Convert.ToInt32(header.FileType);
            int sectionFT = Convert.ToInt32(toSave.SectionType);
            var fileData = getSectionData(toSave);

            string fileName = fileTypes[headerFT][sectionFT];

            //decompress file data if needed
            if (toSave.UncompressedSize > 0)
            {
                GZipStream decompressionStream = new GZipStream(new MemoryStream(fileData),CompressionMode.Decompress);
                byte[] decompressedData = new byte[toSave.UncompressedSize];
                decompressionStream.Read(decompressedData, 0,decompressedData.Length);
                fileData = decompressedData;
            }

            //if the filename is empty at this point, we don't know what action to take
            if (String.IsNullOrEmpty(fileName))
            {
                fileName = "UNKNOWN_" + sectionNumber+"_"+toSave.SectionType;
                File.WriteAllBytes(path + "\\UNHANDLED\\" + fileName, fileData);
            }
            //save file or write directory
            else if (fileName == "file_action")
            {
                //ToDo, extract correct path and filename
                fileName = "FILE_ACTION_" + sectionNumber;
                var fileHeader = new plfFileActionHeader(fileData);

                switch (fileHeader.action)
                {
                    case "directory":
                        if (!Directory.Exists(path + "\\" + fileHeader.path))
                            Directory.CreateDirectory(path + "\\FileSystem\\" + fileHeader.path);
                        break;
                    case "file":
                        //create the target directory if needed
                        if (!Directory.Exists(path + "\\FileSystem\\" + fileHeader.dirPath))
                            Directory.CreateDirectory(path + "\\FileSystem\\" + fileHeader.dirPath);
                        //some files have a ':' in their name, not sure what that's about. Replace them with '.'
                        fileName = Regex.Replace(fileHeader.path, ":", ".");
                        File.WriteAllBytes(path + "\\FileSystem\\" + fileName, fileHeader.fileData);
                        break;
                    case "symlink":
                        //create the target directory if needed
                        if (!Directory.Exists(path + "\\FileSystem\\" + fileHeader.dirPath))
                            Directory.CreateDirectory(path + "\\FileSystem\\" + fileHeader.dirPath);
                        //write the file with a .symlink extension, this will be handled differently when building.
                        File.WriteAllBytes(path + "\\FileSystem\\" + fileHeader.path + ".symlink", fileHeader.fileData);
                        break;
                    default:
                        fileName = fileName + "_" + fileHeader.action;
                        File.WriteAllBytes(path + "\\UNHANDLED\\" + fileName , fileData);
                        break;
                }
            }
            else
            {
                File.WriteAllBytes(path+"\\" + fileName, fileData);
            }
            return 1;
        }

        public int saveSections(string path)
        {
            if(!fileLoaded) return 0;
            int i =0;
            foreach (var section in sections)
            {
                saveSection(path,i);
                i++;
            }
            return 1;
        }
        public byte[] getSectionData(plfSection section)
        {
            byte[] buffer = new byte[section.SectionSize];
            var fs = File.OpenRead(filePath);
            fs.Position = section.LoadAddress;
            fs.Read(buffer, 0, buffer.Length);
            fs.Close();
            return buffer;
        }
    }
}
