﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace plftool
{
    class plfHeader
    {
        private byte[] _headerData;
        public plfHeader(byte[] headerData)
        {
            _headerData = headerData;
        }
        public string Magic { 
            get 
            {
                var valueData = _headerData.Take(4).ToArray();
                return ASCIIEncoding.ASCII.GetString(valueData);
            } 
        }
        public UInt32 HdrVersion
        {
            get
            {
                var valueData = _headerData.Skip(4*1).Take(4).ToArray();
                return BitConverter.ToUInt32(valueData, 0);
            }
        }
        public UInt32 HdrSize
        {
            get
            {
                var valueData = _headerData.Skip(4*2).Take(4).ToArray();
                return BitConverter.ToUInt32(valueData, 0);
            }
        }
        public UInt32 SectHdrSize
        {
            get
            {
                var valueData = _headerData.Skip(4 * 3).Take(4).ToArray();
                return BitConverter.ToUInt32(valueData, 0);
            }
        }
        public UInt32 FileType
        {
            get
            {
                var valueData = _headerData.Skip(4 * 4).Take(4).ToArray();
                return  BitConverter.ToUInt32(valueData, 0);               
            }
        }
        public UInt32 EntryPoint
        {
            get
            {
                var valueData = _headerData.Skip(4 * 5).Take(4).ToArray();
                return BitConverter.ToUInt32(valueData, 0);
            }
        }
        public UInt32 TargetPlatform
        {
            get
            {
                var valueData = _headerData.Skip(4 * 6).Take(4).ToArray();
                return BitConverter.ToUInt32(valueData, 0);
            }
        }
        public UInt32 TargetApplication
        {
            get
            {
                var valueData = _headerData.Skip(4 * 7).Take(4).ToArray();
                return BitConverter.ToUInt32(valueData, 0);
            }
        }
        public UInt32 HardwareCompatibility
        {
            get
            {
                var valueData = _headerData.Skip(4 * 8).Take(4).ToArray();
                return BitConverter.ToUInt32(valueData, 0);
            }
        }
        public UInt32 VersionMajor
        {
            get
            {
                var valueData = _headerData.Skip(4 * 9).Take(4).ToArray();
                return BitConverter.ToUInt32(valueData, 0);
            }
        }
        public UInt32 VersionMinor
        {
            get
            {
                var valueData = _headerData.Skip(4 * 10).Take(4).ToArray();
                return BitConverter.ToUInt32(valueData, 0);
            }
        }
        public UInt32 VersionBugFix
        {
            get
            {
                var valueData = _headerData.Skip(4 * 11).Take(4).ToArray();
                return BitConverter.ToUInt32(valueData, 0);
            }
        }
        public string LanguageZone
        {
            get
            {
                var valueData = _headerData.Skip(4 * 12).Take(4).ToArray();
                return ASCIIEncoding.ASCII.GetString(valueData);
            }
        }
        public UInt32 FileSize
        {
            get
            {
                var valueData = _headerData.Skip(4 * 13).Take(4).ToArray();
                return BitConverter.ToUInt32(valueData, 0);
            }
        }
        
    }
}
