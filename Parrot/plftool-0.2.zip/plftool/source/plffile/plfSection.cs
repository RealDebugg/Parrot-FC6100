﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace plftool
{
    public class plfSection
    {
        private byte[] _sectionHeaderData;
        //public byte[] sectionData;
        public plfSection(byte[] sectionHeaderData, long index)
        {
            _LoadAddress = index;
            _sectionHeaderData = sectionHeaderData;
        }
        public UInt32 SectionType
        {
            get
            {
                var valueData = _sectionHeaderData.Skip(4 * 0).Take(4).ToArray();
                return BitConverter.ToUInt32(valueData, 0);
            }
        }
        public UInt32 SectionSize
        {
            get
            {
                var valueData = _sectionHeaderData.Skip(4 * 1).Take(4).ToArray();
                return BitConverter.ToUInt32(valueData, 0);
            }
        }
        public UInt32 CRC32
        {
            get
            {
                var valueData = _sectionHeaderData.Skip(4 * 2).Take(4).ToArray();
                return BitConverter.ToUInt32(valueData, 0);
            }
        }
        private long _LoadAddress;
        public long LoadAddress
        {
            get
            {
                return _LoadAddress;
            }
        }
        public UInt32 UncompressedSize
        {
            get
            {
                var valueData = _sectionHeaderData.Skip(4 * 4).Take(4).ToArray();
                return BitConverter.ToUInt32(valueData, 0);
            }
        }

    }
}
