﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace plftool
{
    class plfFileActionHeader
    {
        private byte[] _headerData;
        private byte[] _fileData;
        public byte[] flags
        {
            get
            {
                return _headerData.Take(4).ToArray();
            }
        }
        public UInt32 uk_0x04
        {
            get
            {
                return BitConverter.ToUInt32(_headerData.Skip(4*1).Take(4).ToArray(), 0);
            }
        }
        public UInt32 uk_0x08
        {
            get
            {
                return BitConverter.ToUInt32(_headerData.Skip(4 * 2).Take(4).ToArray(), 0);
            }
        }

        public byte[] fileData
        {
            get{
                return _fileData;
            }
        }
        public string action
        {
            get
            {
                switch (flags[1])
                {
                    case 0xA1:
                        return "symlink";
                    case 0x41:
                        return "directory";
                    case 0x81: 
                    case 0x85:
                    case 0x89:
                    case 0x8D:
                        return "file";
                }
                return flags[1].ToString();
            }
        }
        private string _path;
        public string path
        {
            get
            {
                return _path;
            }
        }
        public string dirPath
        {
            get
            {
                if (action == "directory") return path;
                else
                {
                    var dirs = path.Split('/');
                    var dirPath = "";
                    for (int i = 0; i < dirs.Length - 1; i++) dirPath += dirs[i] + "\\";
                    return dirPath;
                }              
            }
        }

        public plfFileActionHeader(byte[] sectionData)
        {
            int filePathEnd = sectionData.ToList().IndexOf(0x00);
            _path = ASCIIEncoding.ASCII.GetString(sectionData.Take(filePathEnd).ToArray());
            _headerData = sectionData.Skip(filePathEnd + 1).Take(12).ToArray();
            _fileData = sectionData.Skip(filePathEnd + 13).ToArray();
        }
    }
}
